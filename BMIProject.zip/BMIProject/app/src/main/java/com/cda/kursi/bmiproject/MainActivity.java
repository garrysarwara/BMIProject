package com.cda.kursi.bmiproject;

import android.app.AlertDialog;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    DatabaseHelper myDB;
    TextView result;
    EditText theight,tweight;
    Button btncalculate;
    Button btnshow;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myDB = new DatabaseHelper(this);
        result = (TextView) findViewById(R.id.txtresult);
        theight = (EditText)findViewById(R.id.txtheight);
        tweight = (EditText)findViewById(R.id.txtweight);
        btncalculate = (Button)findViewById(R.id.btncalculate);
        btnshow = (Button)findViewById(R.id.btnshow);

        AddData();
        viewAll();
    }

    public void AddData() {
        btncalculate.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (  ( !theight.getText().toString().equals("")) && ( !tweight.getText().toString().equals(""))) {
                            boolean isInserted = myDB.insertData(theight.getText().toString(), tweight.getText().toString() );
                            Double rs, h, w;
                            h = Double.parseDouble(theight.getText().toString());
                            w = Double.parseDouble(tweight.getText().toString());
                            rs = w / (h * h);
                            result.setText(" " + rs);
                            if (isInserted = true)
                                Toast.makeText(MainActivity.this, "Data Inserted", Toast.LENGTH_LONG).show();
                            else
                                Toast.makeText(MainActivity.this, "Data is not Inserted", Toast.LENGTH_LONG).show();
                        }}
                }
        );
    }

    public void viewAll() {
        btnshow.setOnClickListener(
                new View.OnClickListener() {
                    public void onClick(View v) {
                        Cursor res = myDB.getAllData();

                        if(res.getCount() == 0) {

                            showMessage("Error","Nothing Found");
                            return;
                        }

                        StringBuffer buffer = new StringBuffer();
                        while(res.moveToNext()) {
                            buffer.append("Height :"+ res.getString(0)+"\n");
                            buffer.append("Weight :"+ res.getString(1)+"\n\n");
                        }
                        showMessage("Data",buffer.toString());
                    }
                }
        );
    }

    public void showMessage(String title,String Message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }
}